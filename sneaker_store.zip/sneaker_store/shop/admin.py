from django.contrib import admin
from .models import Product, Cart, CartItem, Order, OrderItem, SupplierOrder, SupplierOrderItem, Quiz, Question, Choice, UserAnswer, ChatMessage, UserProfile

admin.site.register(Product)
admin.site.register(Cart)
admin.site.register(CartItem)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(SupplierOrder)
admin.site.register(SupplierOrderItem)
admin.site.register(Quiz)
admin.site.register(Question)
admin.site.register(Choice)
admin.site.register(UserAnswer)

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'message', 'is_bot', 'timestamp')
    list_filter = ('is_bot', 'user', 'timestamp')
    search_fields = ('message', 'user__username')
    date_hierarchy = 'timestamp'

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'theme')
    list_filter = ('theme',)
    search_fields = ('user__username',)