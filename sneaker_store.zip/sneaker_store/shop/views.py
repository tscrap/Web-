from django.db.models import QuerySet
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
from django.http import JsonResponse
from .models import Product, Cart, CartItem, Order, OrderItem, SupplierOrder, SupplierOrderItem, Quiz, Question, \
    UserAnswer, ChatMessage, UserProfile, Choice
from .forms import CustomUserCreationForm, OrderForm, SupplierOrderForm, QuizForm
import logging
import json

# Set up logging
logger = logging.getLogger(__name__)


def product_list(request):
    products = Product.objects.all()
    return render(request, 'shop/product_list.html', {'products': products})


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'shop/product_detail.html', {'product': product})


def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
        if not created:
            cart_item.quantity += 1
            cart_item.save()
        return redirect('cart')
    return redirect('login')


@login_required
def cart(request):
    cart = Cart.objects.filter(user=request.user).first()
    if not cart:
        return render(request, 'shop/cart.html', {'cart_items': []})
    cart_items = CartItem.objects.filter(cart=cart)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render(request, 'shop/cart.html', {'cart_items': cart_items, 'total_price': total_price})


@login_required
def create_order(request):
    cart = Cart.objects.filter(user=request.user).first()
    if not cart or not CartItem.objects.filter(cart=cart).exists():
        return redirect('cart')
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            cart_items = CartItem.objects.filter(cart=cart)
            total_price = sum(item.product.price * item.quantity for item in cart_items)
            order = Order.objects.create(
                user=request.user,
                total_price=total_price,
                address=form.cleaned_data['address'],
                status='pending'
            )
            for item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    quantity=item.quantity,
                    price=item.product.price
                )
            cart_items.delete()
            return redirect('profile')
    else:
        form = OrderForm()
    return render(request, 'shop/order_form.html', {'form': form})


@login_required
def order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    items = OrderItem.objects.filter(order=order)
    return render(request, 'shop/order_detail.html', {'order': order, 'items': items})


@login_required
def supplier_order_detail(request, supplier_order_id):
    supplier_order = get_object_or_404(SupplierOrder, id=supplier_order_id, user=request.user)
    items = SupplierOrderItem.objects.filter(supplier_order=supplier_order)
    return render(request, 'shop/supplier_order_detail.html', {'supplier_order': supplier_order, 'items': items})


@login_required
def profile(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    supplier_orders = SupplierOrder.objects.filter(user=request.user).order_by(
        '-created_at') if request.user.groups.filter(name='Sellers').exists() else []
    quizzes = Quiz.objects.all()
    completed_quiz_ids = set(UserAnswer.objects.filter(user=request.user).values_list('quiz_id', flat=True).distinct())
    return render(request, 'shop/profile.html',
                  {'orders': orders, 'supplier_orders': supplier_orders, 'quizzes': quizzes,
                   'completed_quiz_ids': completed_quiz_ids})


@login_required
def create_supplier_order(request):
    if not request.user.groups.filter(name='Sellers').exists():
        return redirect('product_list')
    supplier_order = SupplierOrder.objects.create(user=request.user, status='draft')
    return redirect('edit_supplier_order', supplier_order_id=supplier_order.id)


@login_required
def edit_supplier_order(request, supplier_order_id):
    if not request.user.groups.filter(name='Sellers').exists():
        return redirect('product_list')
    supplier_order = get_object_or_404(SupplierOrder, id=supplier_order_id, user=request.user)
    if request.method == 'POST':
        form = SupplierOrderForm(request.POST)
        if form.is_valid():
            SupplierOrderItem.objects.create(
                supplier_order=supplier_order,
                product=form.cleaned_data['product'],
                quantity=form.cleaned_data['quantity']
            )
            return redirect('edit_supplier_order', supplier_order_id=supplier_order.id)
    else:
        form = SupplierOrderForm()
    items = SupplierOrderItem.objects.filter(supplier_order=supplier_order)
    return render(request, 'shop/supplier_order_edit.html',
                  {'form': form, 'supplier_order': supplier_order, 'items': items})


@login_required
def send_supplier_order(request, supplier_order_id):
    if not request.user.groups.filter(name='Sellers').exists():
        return redirect('product_list')
    supplier_order = get_object_or_404(SupplierOrder, id=supplier_order_id, user=request.user)
    if supplier_order.status == 'draft' and SupplierOrderItem.objects.filter(supplier_order=supplier_order).exists():
        supplier_order.status = 'sent'
        supplier_order.save()
    return redirect('profile')


@login_required
def quiz_detail(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    if UserAnswer.objects.filter(user=request.user, quiz=quiz).exists():
        return redirect('quiz_result', quiz_id=quiz.id)
    questions = Question.objects.filter(quiz=quiz)
    if not questions:
        return render(request, 'shop/quiz_detail.html', {'quiz': quiz, 'error': 'Квиз не содержит вопросов.'})
    if request.method == 'POST':
        form = QuizForm(request.POST, questions=questions)
        if form.is_valid():
            UserAnswer.objects.filter(user=request.user, quiz=quiz).delete()
            for question in questions:
                field_name = f'question_{question.id}'
                user_answer = UserAnswer.objects.create(
                    user=request.user,
                    quiz=quiz,
                    question=question
                )
                choices = form.cleaned_data[field_name]
                if isinstance(choices, QuerySet):
                    choices = list(choices)
                elif not isinstance(choices, list):
                    choices = [choices]
                user_answer.choices.set(choices)
                logger.info(
                    f"Saved answer for user {request.user.username}, quiz {quiz.id}, question {question.id}: {choices}")
            return redirect('quiz_result', quiz_id=quiz.id)
        else:
            logger.error(f"Form validation failed: {form.errors}")
    else:
        form = QuizForm(questions=questions)
    return render(request, 'shop/quiz_detail.html', {'quiz': quiz, 'form': form})


@login_required
def quiz_result(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    user_answers = UserAnswer.objects.filter(user=request.user, quiz=quiz).order_by('question__id')
    logger.info(f"Retrieved {user_answers.count()} answers for user {request.user.username}, quiz {quiz.id}")
    results = []
    correct_count = 0
    total_questions = user_answers.count()
    for answer in user_answers:
        selected_choices = answer.choices.all()
        correct_choices = Choice.objects.filter(question=answer.question, is_correct=True)
        is_correct = set(selected_choices) == set(correct_choices)
        if is_correct:
            correct_count += 1
        results.append({
            'question': answer.question,
            'selected_choices': selected_choices,
            'correct_choices': correct_choices,
            'is_correct': is_correct
        })
    score = (correct_count / total_questions * 100) if total_questions > 0 else 0
    return render(request, 'shop/quiz_result.html', {
        'quiz': quiz,
        'results': results,
        'score': score,
        'correct_count': correct_count,
        'total_questions': total_questions
    })


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            if form.cleaned_data['is_seller']:
                sellers_group, _ = Group.objects.get_or_create(name='Sellers')
                user.groups.add(sellers_group)
            else:
                buyers_group, _ = Group.objects.get_or_create(name='Buyers')
                user.groups.add(buyers_group)
            UserProfile.objects.get_or_create(user=user, defaults={'theme': 'light'})
            login(request, user)
            return redirect('product_list')
    else:
        form = CustomUserCreationForm()
    return render(request, 'shop/register.html', {'form': form})


@login_required
def chatbot(request):
    chat_history = ChatMessage.objects.filter(user=request.user).order_by('timestamp')
    return render(request, 'shop/chatbot.html', {'chat_history': chat_history})


@login_required
def chatbot_message(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message')
            if not user_message:
                return JsonResponse({'error': 'Сообщение не может быть пустым'}, status=400)

            ChatMessage.objects.create(
                user=request.user,
                message=user_message,
                is_bot=False
            )

            qa_pairs = [
                {
                    "question": "как сделать заказ",
                    "answer": "Чтобы сделать заказ, перейдите на страницу товаров, выберите продукт и нажмите 'Добавить в корзину'. Затем перейдите в корзину (/cart/), проверьте товары и нажмите 'Оформить заказ'. Заполните адрес доставки и подтвердите заказ."
                },
                {
                    "question": "как посмотреть товары",
                    "answer": "Все товары доступны на главной странице (/). Вы можете просматривать список товаров или кликнуть на товар для получения подробной информации."
                },
                {
                    "question": "как проверить статус заказа",
                    "answer": "Перейдите в свой профиль (/profile/), где в разделе 'История заказов' вы увидите все ваши заказы с их статусами (например, 'в обработке', 'отправлен'). Нажмите 'Подробности' для дополнительной информации."
                },
                {
                    "question": "как стать продавцом",
                    "answer": "При регистрации отметьте галочку 'Зарегистрироваться как продавец'. После входа в систему вы сможете создавать заказы поставки в профиле (/profile/)."
                },
                {
                    "question": "как пройти квиз",
                    "answer": "В профиле (/profile/) найдите раздел 'Квизы', выберите квиз и нажмите 'Пройти'. Ответьте на все вопросы (выберите один или несколько вариантов в зависимости от типа вопроса) и отправьте ответы."
                },
                {
                    "question": "где посмотреть результаты квиза",
                    "answer": "После прохождения квиза вы будете перенаправлены на страницу результатов. Также в профиле (/profile/) для пройденных квизов появится ссылка 'Результат'."
                },
                {
                    "question": "как связаться с поддержкой",
                    "answer": "Для связи с поддержкой отправьте письмо на support@sneakerstore.com. Укажите ваш вопрос и, если необходимо, номер заказа."
                },
                {
                    "question": "какие бренды есть в магазине",
                    "answer": "В нашем магазине представлены популярные бренды, такие как Nike, Adidas, Puma, Converse, Vans и New Balance. Полный список доступен на странице товаров (/)."
                },
                {
                    "question": "как добавить товар в корзину",
                    "answer": "На странице товара нажмите 'Добавить в корзину'. Вы можете продолжить покупки или перейти в корзину (/cart/) для оформления заказа."
                },
                {
                    "question": "что делать если забыл пароль",
                    "answer": "На странице входа (/login/) нажмите 'Забыли пароль?' и следуйте инструкциям для сброса пароля. Вам будет отправлено письмо с дальнейшими шагами."
                }
            ]

            bot_response = "Извините, я не понял ваш вопрос. Пожалуйста, уточните или задайте другой вопрос, например, 'Как сделать заказ?'."
            for qa in qa_pairs:
                if qa['question'].lower() in user_message.lower():
                    bot_response = qa['answer']
                    break

            ChatMessage.objects.create(
                user=request.user,
                message=bot_response,
                is_bot=True
            )

            return JsonResponse({'user_message': user_message, 'bot_response': bot_response})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Неверный формат данных'}, status=400)
        except Exception as e:
            logger.error(f"Error in chatbot_message: {str(e)}")
            return JsonResponse({'error': 'Произошла ошибка'}, status=500)
    return JsonResponse({'error': 'Метод не разрешен'}, status=405)


@login_required
def update_theme(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            theme = data.get('theme')
            if theme not in ['light', 'dark']:
                return JsonResponse({'error': 'Недопустимая тема'}, status=400)
            profile, created = UserProfile.objects.get_or_create(user=request.user, defaults={'theme': 'light'})
            profile.theme = theme
            profile.save()
            return JsonResponse({'status': 'success', 'theme': theme})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Неверный формат данных'}, status=400)
        except Exception as e:
            logger.error(f"Error in update_theme: {str(e)}")
            return JsonResponse({'error': 'Произошла ошибка'}, status=500)
    return JsonResponse({'error': 'Метод не разрешен'}, status=405)