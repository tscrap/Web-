# Файл: shop/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import SupplierOrderItem, Question, Choice, Product


class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    is_seller = forms.BooleanField(label='Зарегистрироваться как продавец', required=False)
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'is_seller']

class OrderForm(forms.Form):
    address = forms.CharField(max_length=255, label='Адрес доставки')

class SupplierOrderForm(forms.Form):
    product = forms.ModelChoiceField(queryset=Product.objects.all(), label='Товар')
    quantity = forms.IntegerField(min_value=1, label='Количество')

class QuizForm(forms.Form):
    def __init__(self, *args, **kwargs):
        questions = kwargs.pop('questions')
        super().__init__(*args, **kwargs)
        for question in questions:
            choices = Choice.objects.filter(question=question)
            field_name = f'question_{question.id}'
            if question.is_multiple_choice:
                self.fields[field_name] = forms.ModelMultipleChoiceField(
                    queryset=choices,
                    widget=forms.CheckboxSelectMultiple,
                    label=question.text,
                    required=True
                )
            else:
                self.fields[field_name] = forms.ModelChoiceField(
                    queryset=choices,
                    widget=forms.RadioSelect,
                    label=question.text,
                    required=True
                )