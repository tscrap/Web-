from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('product/<int:pk>/', views.product_detail, name='product_detail'),
    path('add_to_cart/<int:pk>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('create_order/', views.create_order, name='create_order'),
    path('order/<int:order_id>/', views.order_detail, name='order_detail'),
    path('profile/', views.profile, name='profile'),
    path('create_supplier_order/', views.create_supplier_order, name='create_supplier_order'),
    path('edit_supplier_order/<int:supplier_order_id>/', views.edit_supplier_order, name='edit_supplier_order'),
    path('send_supplier_order/<int:supplier_order_id>/', views.send_supplier_order, name='send_supplier_order'),
    path('supplier_order/<int:supplier_order_id>/', views.supplier_order_detail, name='supplier_order_detail'),
    path('quiz/<int:quiz_id>/', views.quiz_detail, name='quiz_detail'),
    path('quiz/<int:quiz_id>/result/', views.quiz_result, name='quiz_result'),
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='shop/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='product_list'), name='logout'),
    path('chatbot/', views.chatbot, name='chatbot'),
    path('chatbot/message/', views.chatbot_message, name='chatbot_message'),
    path('update_theme/', views.update_theme, name='update_theme'),
]
